VIDEO_PH

<ul class="list-unstyled">
	<li><strong>INGREDIENTS_I18N: </strong> INGREDIENTS_PH</li>
	<li><strong>COOKING_TIME_I18N: </strong> COOKING_TIME_PH</li>
	<li><strong>UTENSILS_I18N: </strong> UTENSILS_PH</li>
	<li><strong>LEVEL_I18N: </strong> LEVEL_PH</li>
	<li><strong>TYPE_I18N: </strong> TYPE_PH</li>
    <li><strong>ORIGIN_I18N: </strong> ORIGIN_PH MORE_INFO_URL_PH</li>
	<li>
		<strong>RATE_I18N: </strong>
		<div id="recipe_rating" class="rateit"
		     data-rateit-resetable="false"
             data-rateit-value="RECIPE_RATING"
             READONLY_PLACEHOLDER
		     data-rid="RECIPE_ID"></div>
	</li>
</ul>